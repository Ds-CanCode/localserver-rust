class InputManager {
    constructor() {
        this.currentKeys = new Set()
        this.prevsKeys = new Set()
        
        this.#initEvents()
    }

    #initEvents() {
        document.addEventListener("keydown", this.#handleKeyDown)
        document.addEventListener("keyup", this.#handleKeyUp)
    }

    #handleKeyDown = (e) => {
        this.currentKeys.add(e.key.toLowerCase());    
    }

    #handleKeyUp = (e) => {
        this.currentKeys.delete(e.key.toLowerCase())
    }

    update() {
        this.prevsKeys = new Set(this.currentKeys)
    }

    isPressed(key) {
        key = key.toLowerCase()
        return !this.prevsKeys.has(key) && this.currentKeys.has(key)
    }

    isHold(key) {
        key = key.toLowerCase()
        return this.currentKeys.has(key) 
    }

}


export default new InputManager()
