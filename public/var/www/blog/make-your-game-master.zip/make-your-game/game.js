import inputManager from "./inputManager.js";

class Game {

    constructor() {
        this.initializeElements();
        this.initializeGameState();
        this.setupEventListeners();
        this.createBricks();
        this.startGameLoop();
    }

    initializeElements() {
        // Get references to the game elements
        this.paddle = document.getElementById('paddle');
        this.ball = document.getElementById('ball');
        this.container = document.getElementById('gameContainer');
        this.pauseMenu = document.getElementById('pauseMenu');
        this.scoreElement = document.getElementById('score');
        this.livesElement = document.getElementById('lives');
        this.timeElement = document.getElementById('time');

    }
    initializeGameState() {
        // Initialize score, lives and game time
        this.score = 0;
        this.lives = 3;
        this.gameTime = 0;
        this.lastTime = 0;
        this.paused = false;
        
        // Set initial paddle position
        this.paddleX = 350;
        // Set initial ball position
        this.ballX = 400;
        this.ballY = 300;
        // Set initial ball speed
        this.ballSpeed = 7; // Base ball speed
        // Set initial ball direction
        this.setBallDirection(Math.PI * -0.25); // Initial 45-degree angle
        
    }
    setBallDirection(angle) {
        this.ballSpeedX = this.ballSpeed * Math.cos(angle);
        this.ballSpeedY = this.ballSpeed * Math.sin(angle);
    }
    createBricks() {
        const rows = 5; // Number of rows of bricks
        const cols = 8; // Number of columns of bricks
        const brickWidth = 80; // Width of each brick
        const brickHeight = 30; // Height of each brick
        const padding = 15; // Padding between bricks
        const colors = ['#f94144', '#f3722c', '#f8961e', '#f9c74f', '#90be6d']; // Colors for each row
        
        // Loop through rows and columns to create all the bricks
        for (let i = 0; i < rows; i++) {
            for (let j = 0; j < cols; j++) {
                const colorrand = Math.floor(Math.random()*5)
                const brick = document.createElement('div');
                brick.className = 'brick'; // Assign the class "brick" to the element
                // Set the position of the brick based on its row and column
                brick.style.left = (j * (brickWidth + padding) + padding) + 'px';
                brick.style.top = (i * (brickHeight + padding) + padding) + 'px';
                // Set the background color of the brick based on its row
                brick.style.background = colors[colorrand];
                // Add the brick to the game container
                this.container.appendChild(brick);
            }
        }
    }
    setupEventListeners() {
        // Set up event listener for the continue button
        document.getElementById('continueBtn').addEventListener('click', () => this.togglePause());
        // Set up event listener for the restart button
        document.getElementById('restartBtn').addEventListener('click', () => this.restart());
    }
    togglePause() {
        // Toggle the paused state
        this.paused = !this.paused;
        // Display or hide the pause menu based on the paused state
        this.pauseMenu.style.display = this.paused ? 'block' : 'none';
    }
    restart() {
        this.initializeGameState();
        // Update display
        this.scoreElement.textContent = this.score;
        this.livesElement.textContent = this.lives;
        this.timeElement.textContent = '0';
        // Remove existing bricks and create new ones
        const bricks = document.querySelectorAll('.brick');
        bricks.forEach(brick => brick.remove());
        this.createBricks();
        // Reset the paused state and hide the pause menu
        this.paused = false;
        this.pauseMenu.style.display = 'none';
    }
    showWinScreen() {
        alert('You win!');
        this.restart();
    }
    handleBallCollisions() {
        // Ball collision with walls
        if (this.ballX <= 0 || this.ballX >= 775) {
            this.ballSpeedX *= -1;
            console.log('Ball collided with wall');
        }
        if (this.ballY <= 0) {
            this.ballSpeedY *= -1;
            console.log('Ball collided with top wall');
        }
        // Ball collision with paddle
        if (this.ballY >= 560 && this.ballY <= 580 &&
            this.ballX >= this.paddleX && this.ballX <= this.paddleX + 100) {
            // Calculate where the ball hit the paddle (0 = left edge, 1 = right edge)
            const hitPosition = (this.ballX - this.paddleX) / 100;
            // Calculate new angle based on hit position
            // Range from -60 degrees (left) to -120 degrees (right)
            const angle = Math.PI * (-0.67 + (hitPosition * 0.34));
            // Set new direction and slightly increase speed
            this.ballSpeed = Math.min(this.ballSpeed * 1.05, 12);
            console.log(`Ball hit paddle at position ${hitPosition}, new angle: ${angle}`);
            this.setBallDirection(angle);
        }
        // Ball out of bounds
        if (this.ballY > 600) {
            this.lives--;
            this.livesElement.textContent = this.lives;
            if (this.lives <= 0) {
                console.log('Game over');
                this.restart();
                return;
            }
            this.ballX = 400;
            this.ballY = 300;
            this.ballSpeed = 7;
            this.setBallDirection(Math.PI * -0.25);
            console.log('Ball out of bounds, reseting position and speed');
        }
        // Ball collision with bricks
        const bricks = document.querySelectorAll('.brick');
        bricks.forEach(brick => {
            const rect = brick.getBoundingClientRect();
            const containerRect = this.container.getBoundingClientRect();
            const brickX = rect.left - containerRect.left;
            const brickY = rect.top - containerRect.top;
            
            
            if (this.ballX + 15 >= brickX && this.ballX <= brickX + 80 &&
                this.ballY + 15 >= brickY && this.ballY <= brickY + 30) {
                brick.remove();
                console.log(`Ball collided with brick at x=${brickX}, y=${brickY}`);
                this.ballSpeedY *= -1;
                this.score += 10;
                this.scoreElement.textContent = this.score;
            }
        });
        if (document.querySelectorAll('.brick').length === 0) {
            this.showWinScreen();
        }
        
    }

    update(deltaTime) {
        if (this.paused) return;
        // Update game time
        this.gameTime += deltaTime;
        this.timeElement.textContent = Math.floor(this.gameTime);
    // Move paddle
        const paddleSpeed = 12;
        const containerWidth = this.container.offsetWidth;
        const paddleWidth = this.paddle.offsetWidth;

        if (inputManager.isHold('ArrowLeft')) {
            this.paddleX = Math.max(0, this.paddleX - paddleSpeed);
        }
        if (inputManager.isHold('ArrowRight')) {
            this.paddleX = Math.min(containerWidth - paddleWidth, this.paddleX + paddleSpeed);
        }
       
        this.ballX += this.ballSpeedX;
        this.ballY += this.ballSpeedY;
        this.handleBallCollisions();
        // Update positions using transform for better performance
        this.paddle.style.transform = `translateX(${this.paddleX}px)`;
        this.ball.style.transform = `translate(${this.ballX}px, ${this.ballY}px)`;
    }
    gamePause() {
        if (inputManager.isPressed("p")) {
            this.togglePause()
        } 
    }
    startGameLoop() {
        let prevTime = 0
        const gameLoop = () => {
            let currentTime = performance.now()
            let dt = (currentTime - prevTime) / 1000;
            prevTime = currentTime
            this.update(dt);
            this.gamePause()
            inputManager.update()
            requestAnimationFrame(gameLoop);
        };
        requestAnimationFrame(gameLoop);
    }
}

// Start the game when the DOM is fully loaded
new Game();

